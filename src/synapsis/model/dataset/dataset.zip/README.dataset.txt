# facial fatigue > 2024-05-13 5:12pm
https://universe.roboflow.com/local-project/facial-fatigue

Provided by a Roboflow user
License: CC BY 4.0

